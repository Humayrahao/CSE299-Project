
<?php include('partials/menu.php');
?>



      <!--Main content section starts-->
      <div class="main-content">
        <div class="wraper">
        <h1>DASHBOARD</h1>
        <br><br>

        <?php
        if(isset($_SESSION['login']))//checking session set or not
        {

            echo $_SESSION['login'];//display session massage
            unset($_SESSION['login']); //remove session message

        }
        ?>
        <br><br>

          <div class="col-4 text-center">
            <h1>5</h1>
            <br />
            Categories
          </div>

          <div class="col-4 text-center">
            <h1>5</h1>
            <br />
            Categories
          </div>

          <div class="col-4 text-center">
            <h1>5</h1>
            <br />
            Categories
          </div>

          <div class="col-4 text-center">
            <h1>5</h1>
            <br />
            Categories
          </div>

         <div class="clearfix"></div>
      </div>
    </div>
      <!--Main content section ends-->

      <?php include('partials/footer.php');
      ?>
