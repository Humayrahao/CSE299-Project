<!--Footer Section starts-->
<div class="footer">
  <div class="wraper">
   <p class="text-center"> 2021 All rights reserved by, Sadiya A. Anamika & Humayra Akhter</p>
</div>
</div>
<!--Footer Section ends-->


</body>
</html>
